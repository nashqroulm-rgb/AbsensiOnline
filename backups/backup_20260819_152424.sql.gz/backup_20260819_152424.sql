


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


CREATE SCHEMA IF NOT EXISTS "public";


ALTER SCHEMA "public" OWNER TO "pg_database_owner";


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE OR REPLACE FUNCTION "public"."derive_attendance_status"("p_checkin_at" timestamp with time zone, "p_shift_id" "uuid") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_shift RECORD;
  v_scheduled TIMESTAMPTZ;
  v_diff_min DOUBLE PRECISION;
BEGIN
  SELECT jam_mulai, toleransi_menit INTO v_shift FROM shifts WHERE id = p_shift_id;
  IF NOT FOUND THEN RETURN 'hadir'; END IF;

  v_scheduled := (p_checkin_at::date || ' ' || v_shift.jam_mulai || ':00+07')::timestamptz;
  v_diff_min := EXTRACT(EPOCH FROM (p_checkin_at - v_scheduled)) / 60;

  IF v_diff_min > v_shift.toleransi_menit THEN
    RETURN 'terlambat';
  ELSE
    RETURN 'hadir';
  END IF;
END;
$$;


ALTER FUNCTION "public"."derive_attendance_status"("p_checkin_at" timestamp with time zone, "p_shift_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_user_by_no_hp"("p_no_hp" "text") RETURNS TABLE("id" "uuid", "nama" "text", "no_hp" "text", "jabatan" "text", "role" "text", "zona_id" "uuid", "shift_id" "uuid", "status" "text", "tipe" "text", "gender" "text", "foto" "text", "bergabung_sejak" "date", "absensi_online" boolean)
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT
    u.id, u.nama, u.no_hp, u.jabatan, u.role,
    u.zona_id, u.shift_id, u.status, u.tipe,
    u.gender, u.foto, u.bergabung_sejak, u.absensi_online
  FROM users u
  WHERE u.no_hp = p_no_hp
    AND u.status = 'aktif'
  LIMIT 1;
$$;


ALTER FUNCTION "public"."get_user_by_no_hp"("p_no_hp" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_attendance_status_on_write"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF NEW.checkin_at IS NOT NULL AND NEW.shift_id IS NOT NULL THEN
    NEW.status := derive_attendance_status(NEW.checkin_at, NEW.shift_id);
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."set_attendance_status_on_write"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_updated_at"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."app_settings" (
    "id" integer DEFAULT 1 NOT NULL,
    "company_name" "text" DEFAULT 'AbsensiOnline'::"text" NOT NULL,
    "timezone" "text" DEFAULT 'Asia/Jakarta'::"text" NOT NULL,
    "default_zone_radius_m" integer DEFAULT 150 NOT NULL,
    "default_shift_tolerance_min" integer DEFAULT 15 NOT NULL,
    "max_file_size_mb" integer DEFAULT 5 NOT NULL,
    "max_attachments_per_day" integer DEFAULT 10 NOT NULL,
    "max_photos_per_day" integer DEFAULT 5 NOT NULL,
    "max_docs_per_day" integer DEFAULT 5 NOT NULL,
    "gps_timeout_ms" integer DEFAULT 10000 NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "app_settings_id_check" CHECK (("id" = 1)),
    CONSTRAINT "chk_default_radius" CHECK ((("default_zone_radius_m" > 0) AND ("default_zone_radius_m" <= 10000))),
    CONSTRAINT "chk_default_tolerance" CHECK ((("default_shift_tolerance_min" >= 0) AND ("default_shift_tolerance_min" <= 120))),
    CONSTRAINT "chk_gps_timeout" CHECK ((("gps_timeout_ms" >= 3000) AND ("gps_timeout_ms" <= 60000))),
    CONSTRAINT "chk_max_attachments" CHECK ((("max_attachments_per_day" >= 1) AND ("max_attachments_per_day" <= 50))),
    CONSTRAINT "chk_max_docs" CHECK ((("max_docs_per_day" >= 0) AND ("max_docs_per_day" <= 50))),
    CONSTRAINT "chk_max_file_size" CHECK ((("max_file_size_mb" >= 1) AND ("max_file_size_mb" <= 50))),
    CONSTRAINT "chk_max_photos" CHECK ((("max_photos_per_day" >= 0) AND ("max_photos_per_day" <= 50)))
);


ALTER TABLE "public"."app_settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."attachments" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "attendance_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "tipe" "text" NOT NULL,
    "url" "text" NOT NULL,
    "nama_file" "text" NOT NULL,
    "ukuran_bytes" integer NOT NULL,
    "status_verifikasi" "text" DEFAULT 'menunggu'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "attachments_status_verifikasi_check" CHECK (("status_verifikasi" = ANY (ARRAY['terverifikasi'::"text", 'menunggu'::"text", 'ditolak'::"text"]))),
    CONSTRAINT "attachments_tipe_check" CHECK (("tipe" = ANY (ARRAY['foto'::"text", 'dokumen'::"text"])))
);


ALTER TABLE "public"."attachments" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."attendances" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "user_nama" "text" NOT NULL,
    "shift_id" "uuid" NOT NULL,
    "zona_id" "uuid" NOT NULL,
    "checkin_at" timestamp with time zone,
    "checkout_at" timestamp with time zone,
    "durasi_menit" integer,
    "status" "text" DEFAULT 'absen'::"text" NOT NULL,
    "client_timestamp" timestamp with time zone,
    "synced_at" timestamp with time zone,
    "latitude_in" double precision,
    "longitude_in" double precision,
    "latitude_out" double precision,
    "longitude_out" double precision,
    "lampiran_count" integer DEFAULT 0 NOT NULL,
    "catatan" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "attendances_status_check" CHECK (("status" = ANY (ARRAY['hadir'::"text", 'terlambat'::"text", 'absen'::"text", 'izin'::"text", 'libur'::"text", 'sakit'::"text", 'cuti'::"text"])))
);


ALTER TABLE "public"."attendances" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."shifts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nama" "text" NOT NULL,
    "jam_mulai" "text" NOT NULL,
    "jam_selesai" "text" NOT NULL,
    "toleransi_menit" integer DEFAULT 15 NOT NULL,
    "status" "text" DEFAULT 'aktif'::"text" NOT NULL,
    "ikon" "text" DEFAULT '🏢'::"text" NOT NULL,
    "hari_kerja" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "chk_toleransi" CHECK (("toleransi_menit" >= 0)),
    CONSTRAINT "shifts_status_check" CHECK (("status" = ANY (ARRAY['aktif'::"text", 'nonaktif'::"text"])))
);


ALTER TABLE "public"."shifts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."users" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nama" "text" NOT NULL,
    "no_hp" "text" NOT NULL,
    "jabatan" "text" DEFAULT ''::"text" NOT NULL,
    "role" "text" DEFAULT 'worker'::"text" NOT NULL,
    "zona_id" "uuid",
    "shift_id" "uuid",
    "status" "text" DEFAULT 'aktif'::"text" NOT NULL,
    "tipe" "text" DEFAULT 'tetap'::"text" NOT NULL,
    "gender" "text" DEFAULT 'pria'::"text" NOT NULL,
    "foto" "text",
    "bergabung_sejak" "date" DEFAULT CURRENT_DATE NOT NULL,
    "absensi_online" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "users_gender_check" CHECK (("gender" = ANY (ARRAY['pria'::"text", 'wanita'::"text"]))),
    CONSTRAINT "users_role_check" CHECK (("role" = ANY (ARRAY['worker'::"text", 'admin'::"text", 'super_admin'::"text"]))),
    CONSTRAINT "users_status_check" CHECK (("status" = ANY (ARRAY['aktif'::"text", 'nonaktif'::"text"]))),
    CONSTRAINT "users_tipe_check" CHECK (("tipe" = ANY (ARRAY['tetap'::"text", 'kontrak'::"text", 'harian'::"text"])))
);


ALTER TABLE "public"."users" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."zones" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nama" "text" NOT NULL,
    "deskripsi" "text" DEFAULT ''::"text" NOT NULL,
    "latitude" double precision NOT NULL,
    "longitude" double precision NOT NULL,
    "radius_meter" integer DEFAULT 150 NOT NULL,
    "status" "text" DEFAULT 'aktif'::"text" NOT NULL,
    "color" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "chk_latitude" CHECK ((("latitude" >= ('-90'::integer)::double precision) AND ("latitude" <= (90)::double precision))),
    CONSTRAINT "chk_longitude" CHECK ((("longitude" >= ('-180'::integer)::double precision) AND ("longitude" <= (180)::double precision))),
    CONSTRAINT "chk_radius" CHECK ((("radius_meter" > 0) AND ("radius_meter" <= 10000))),
    CONSTRAINT "zones_status_check" CHECK (("status" = ANY (ARRAY['aktif'::"text", 'nonaktif'::"text"])))
);


ALTER TABLE "public"."zones" OWNER TO "postgres";


ALTER TABLE ONLY "public"."app_settings"
    ADD CONSTRAINT "app_settings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."attachments"
    ADD CONSTRAINT "attachments_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."attendances"
    ADD CONSTRAINT "attendances_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."shifts"
    ADD CONSTRAINT "shifts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_no_hp_key" UNIQUE ("no_hp");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."zones"
    ADD CONSTRAINT "zones_pkey" PRIMARY KEY ("id");



CREATE INDEX "idx_attachments_attendance" ON "public"."attachments" USING "btree" ("attendance_id");



CREATE INDEX "idx_attachments_user" ON "public"."attachments" USING "btree" ("user_id");



CREATE INDEX "idx_attendances_date" ON "public"."attendances" USING "btree" ("checkin_at" DESC);



CREATE UNIQUE INDEX "idx_attendances_one_checkin_per_day" ON "public"."attendances" USING "btree" ("user_id", ((("checkin_at" AT TIME ZONE 'Asia/Jakarta'::"text"))::"date")) WHERE ("checkin_at" IS NOT NULL);



CREATE INDEX "idx_attendances_status" ON "public"."attendances" USING "btree" ("status");



CREATE INDEX "idx_attendances_user_date" ON "public"."attendances" USING "btree" ("user_id", "checkin_at" DESC);



CREATE INDEX "idx_attendances_zona" ON "public"."attendances" USING "btree" ("zona_id");



CREATE INDEX "idx_users_no_hp_role" ON "public"."users" USING "btree" ("no_hp", "role");



CREATE INDEX "idx_users_shift" ON "public"."users" USING "btree" ("shift_id");



CREATE INDEX "idx_users_zona" ON "public"."users" USING "btree" ("zona_id");



CREATE OR REPLACE TRIGGER "trg_attendance_status_on_insert" BEFORE INSERT ON "public"."attendances" FOR EACH ROW EXECUTE FUNCTION "public"."set_attendance_status_on_write"();



CREATE OR REPLACE TRIGGER "trg_attendance_status_on_update" BEFORE UPDATE OF "checkin_at", "shift_id" ON "public"."attendances" FOR EACH ROW WHEN ((("new"."checkin_at" IS NOT NULL) AND ("new"."shift_id" IS NOT NULL))) EXECUTE FUNCTION "public"."set_attendance_status_on_write"();



CREATE OR REPLACE TRIGGER "trigger_app_settings_updated_at" BEFORE UPDATE ON "public"."app_settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_attendances_updated_at" BEFORE UPDATE ON "public"."attendances" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_shifts_updated_at" BEFORE UPDATE ON "public"."shifts" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_users_updated_at" BEFORE UPDATE ON "public"."users" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_zones_updated_at" BEFORE UPDATE ON "public"."zones" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at"();



ALTER TABLE ONLY "public"."attachments"
    ADD CONSTRAINT "attachments_attendance_id_fkey" FOREIGN KEY ("attendance_id") REFERENCES "public"."attendances"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."attachments"
    ADD CONSTRAINT "attachments_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."attendances"
    ADD CONSTRAINT "attendances_shift_id_fkey" FOREIGN KEY ("shift_id") REFERENCES "public"."shifts"("id");



ALTER TABLE ONLY "public"."attendances"
    ADD CONSTRAINT "attendances_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."attendances"
    ADD CONSTRAINT "attendances_zona_id_fkey" FOREIGN KEY ("zona_id") REFERENCES "public"."zones"("id");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_shift_id_fkey" FOREIGN KEY ("shift_id") REFERENCES "public"."shifts"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_zona_id_fkey" FOREIGN KEY ("zona_id") REFERENCES "public"."zones"("id") ON DELETE SET NULL;



ALTER TABLE "public"."app_settings" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "app_settings_select_authenticated" ON "public"."app_settings" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "app_settings_update_admin" ON "public"."app_settings" FOR UPDATE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



ALTER TABLE "public"."attachments" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "attachments_delete_admin" ON "public"."attachments" FOR DELETE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "attachments_insert_own" ON "public"."attachments" FOR INSERT TO "authenticated" WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "attachments_select_admin" ON "public"."attachments" FOR SELECT TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "attachments_select_own" ON "public"."attachments" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "attachments_update_admin" ON "public"."attachments" FOR UPDATE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



ALTER TABLE "public"."attendances" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "attendances_delete_admin" ON "public"."attendances" FOR DELETE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "attendances_insert_own" ON "public"."attendances" FOR INSERT TO "authenticated" WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "attendances_select_admin" ON "public"."attendances" FOR SELECT TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "attendances_select_own" ON "public"."attendances" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "attendances_update_admin" ON "public"."attendances" FOR UPDATE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "attendances_update_own" ON "public"."attendances" FOR UPDATE TO "authenticated" USING (("user_id" = "auth"."uid"()));



ALTER TABLE "public"."shifts" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "shifts_delete_admin" ON "public"."shifts" FOR DELETE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "shifts_insert_admin" ON "public"."shifts" FOR INSERT TO "authenticated" WITH CHECK (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "shifts_select_all" ON "public"."shifts" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "shifts_update_admin" ON "public"."shifts" FOR UPDATE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



ALTER TABLE "public"."users" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "users_delete_admin" ON "public"."users" FOR DELETE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "users_insert_admin" ON "public"."users" FOR INSERT TO "authenticated" WITH CHECK (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "users_select_admin" ON "public"."users" FOR SELECT TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "users_select_own" ON "public"."users" FOR SELECT TO "authenticated" USING (("id" = "auth"."uid"()));



CREATE POLICY "users_update_admin" ON "public"."users" FOR UPDATE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



ALTER TABLE "public"."zones" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "zones_delete_admin" ON "public"."zones" FOR DELETE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "zones_insert_admin" ON "public"."zones" FOR INSERT TO "authenticated" WITH CHECK (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



CREATE POLICY "zones_select_all" ON "public"."zones" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "zones_update_admin" ON "public"."zones" FOR UPDATE TO "authenticated" USING (((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text") = ANY (ARRAY['admin'::"text", 'super_admin'::"text"])));



GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";



GRANT ALL ON FUNCTION "public"."derive_attendance_status"("p_checkin_at" timestamp with time zone, "p_shift_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."derive_attendance_status"("p_checkin_at" timestamp with time zone, "p_shift_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."derive_attendance_status"("p_checkin_at" timestamp with time zone, "p_shift_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."get_user_by_no_hp"("p_no_hp" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."get_user_by_no_hp"("p_no_hp" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_user_by_no_hp"("p_no_hp" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."set_attendance_status_on_write"() TO "anon";
GRANT ALL ON FUNCTION "public"."set_attendance_status_on_write"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_attendance_status_on_write"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_updated_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_updated_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_updated_at"() TO "service_role";



GRANT ALL ON TABLE "public"."app_settings" TO "anon";
GRANT ALL ON TABLE "public"."app_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."app_settings" TO "service_role";



GRANT ALL ON TABLE "public"."attachments" TO "anon";
GRANT ALL ON TABLE "public"."attachments" TO "authenticated";
GRANT ALL ON TABLE "public"."attachments" TO "service_role";



GRANT ALL ON TABLE "public"."attendances" TO "anon";
GRANT ALL ON TABLE "public"."attendances" TO "authenticated";
GRANT ALL ON TABLE "public"."attendances" TO "service_role";



GRANT ALL ON TABLE "public"."shifts" TO "anon";
GRANT ALL ON TABLE "public"."shifts" TO "authenticated";
GRANT ALL ON TABLE "public"."shifts" TO "service_role";



GRANT ALL ON TABLE "public"."users" TO "anon";
GRANT ALL ON TABLE "public"."users" TO "authenticated";
GRANT ALL ON TABLE "public"."users" TO "service_role";



GRANT ALL ON TABLE "public"."zones" TO "anon";
GRANT ALL ON TABLE "public"."zones" TO "authenticated";
GRANT ALL ON TABLE "public"."zones" TO "service_role";



ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";







